import React,{useEffect} from "react";
const Aboutus = () => {
    useEffect(() => {
        document.title="About || About My-App";
    },[]);
   return(
       <h1>About us</h1>
   );
};
export default Aboutus;