import React,{useEffect} from "react";
const Contact = () => {
    useEffect(() => {
        document.title="Contact || Contact with My-App";
    },[]);
   return(
       <h1>Contact us</h1>
   );
};
export default Contact;