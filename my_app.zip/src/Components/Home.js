import { hover} from "@testing-library/user-event/dist/hover";
import React, {useEffect} from "react";
import {jumbotron,Container,Button} from "reactstrap";
const Home = ()=> {
    useEffect(() => {
        document.title = "Home || Learn code with my-App";
    },[]);
    return(
        <div>
            <jumbotron className="text-center bg-primary" outline>
                <h2>It's a simple Fullstack project with CRUD operations</h2>
                <p>It's a Frontend as well as backend project.</p>
                <Container>
                    <Button color="primary">Let's Explore</Button>
                </Container>
            </jumbotron>
        </div>
    );
    
}
export default Home;
