import React, { Fragment,useEffect, useState } from "react";
import { Button,Container,Form,FormGroup,Label,Input } from "reactstrap";
import axios from "axios";
import base_url from "../api/bootapi";
import { toast } from "react-toastify";
const AddCourse = ()=> {
       useEffect(() => {
           document.title="AddCourse || Learn with My-App";
        },[]);

        const[course,setCourse]=useState({});
        //Form handler dfunction
        const handleForm=(e) => {
            console.log(course);
            postDatatoServer(course);
            e.preventDefault();
        };

//creating function to post on server
    const postDatatoServer = (data) =>{
        axios.post('{$base_url}/courses',data).then(
            (response) => {
                //success
                console.log(response);
                console.log("success");
                toast.success("Course added successfully",{position: "bottom-center"});
            },
            (error) =>{
                //error
                console.log(error);
                toast.error("Something went wrong",{
                    position: "bottom-center",
                });
            }
        );    
     };

 return (
     <Fragment>
         <h1 className="text-center my-3">Fill the Product details</h1>
        <Form onSubmit={handleForm}>
            <FormGroup>
                <Label for="CourseId">Product Id</Label>
                <Input 
                id="CourseId"
                name="CourseId"
                placeholder="Enter here"
                type="text"
                onChange={(e)=>{
                    setCourse({...course,id:e.target.value})
                }}
                />
            </FormGroup>

            <FormGroup>
                <Label for="CourseTitle">Product Title</Label>
                <Input 
                id="CourseTitle"
                name="CourseTitle"
                placeholder="Enter here"
                type="text"
                onChange={(e)=>{
                    setCourse({...course,title:e.target.value})
                }}
                />
            </FormGroup>

            <FormGroup>
                <Label for="CourseDescription">Product Description</Label>
                <Input 
                id="CourseDescription"
                name="CourseDescription"
                placeholder="Enter here"
                type="text"
                style={{height:150}}
                onChange={(e)=>{
                    setCourse({...course,description:e.target.value})
                }}
                />
            </FormGroup>

            <Container className="text-center">
                <Button type="submit" color="success">Add Product</Button>
                {' '}
                <Button type="reset" color="warning ml-2">Clear Product</Button>
            </Container>
        </Form>

     </Fragment>
    );
   
};
export default AddCourse;