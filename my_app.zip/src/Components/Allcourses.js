import React, {useState, useEffect} from "react";
import base_url from "../api/bootapi";
import axios from "axios";
import { toast } from "react-toastify";
import Course from "./Course";

const Allcourses = ()=> {
  useEffect(() => {
      document.title = "Allcourses || with My-App";
  },[]);


  //Function to call server
  const getAllCoursesFromServer = () => {
      axios.get('${base_url}/courses').then(
          (response) => {
              //success
              console.log(response.data);
              toast.success("Course has been loaded",{
                  position:"bottom-center",
              });
              setCourses(response.data);
          },
          (error) => {
              //error
              console.log(error);
              toast.error("Something went wrong",{
                  position:"bottom-center",
              });
          }

          
      );
  };

  // call loading course function

  useEffect(() => {
    getAllCoursesFromServer();
  },[]);
    const [courses,setCourses]=useState([

    ]);

    const updateCourses = (id) => {
        setCourses(courses.filter((c) => c.id != id));
    };
      
return(
    <div>
        <h1>All Product</h1>
        <p>List of Products are as follows</p>
        {
            courses.length>0
            ?courses.map((item)=><Course key={item.id} course={item} update={updateCourses}/>)
            :"No Product"

        }
    </div>

);
};
export default Allcourses;