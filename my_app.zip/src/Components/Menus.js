import React from "react";
import { Link, Router } from "react-router-dom";

import { ListGroup, ListGroupItem } from "reactstrap";
import AddCourse from "./AddCourse";
const Menus = () => {
    return(
        <ListGroup>
            <Link className="list-group-item list-group-item-action" tag="a" to="/" action>
                Home
            </Link>

            <Link className="list-group-item list-group-item-action" tag="a" to="/add-course" action>
            AddProduct
            </Link>

            <Link className="list-group-item list-group-item-action" tag="a" to="/view-courses" action>
            ViewProduct
            </Link>

            <Link className="list-group-item list-group-item-action" tag="a" to="/about" action>
            About Us
            </Link>

            <Link className="list-group-item list-group-item-action" tag="a" to="/contact" action>
            Contact Us
            </Link>
        </ListGroup>
    );
};
export default Menus;