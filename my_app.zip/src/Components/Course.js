import React from "react";
import {Card,CardBody,CardText,Container,Button, CardSubtitle} from "reactstrap";
import axios from "axios";
import base_url from "../api/bootapi";
import { toast } from "react-toastify";


const Course=({course,update})=>{
    const deleteCourse=(id)=>{
        axios.delete('${base_url}/courses/${id}').then(
            (resoonse) => {
                //success
                toast.success("Course is deleted",{
                    position:"bottom-center",
                });
                update(id);
            },
            (error) => {
                //error
                toast.error("Course is not deleted" ,{
                    position:"bottom-center",
                });
            }
        )
    }
    
    const updateCourse=(id)=>{
        axios.put('${base_url}/courses').then(
            (resoonse) => {
                //success
                toast.success("Course is updated",{
                    position:"bottom-center",
                });
                // update(id);
            },
            (error) => {
                //error
                toast.error("Course is not updated" ,{
                    position:"bottom-center",
                });
            }
        )
    }

    return(
    <Card className="text-center">
        <CardBody>
            <CardSubtitle className="font-weight-bold">{course.title}</CardSubtitle>
            <CardText>{course.description}</CardText>
            <Container className="text-center">

                <Button color="danger" 
                onClick={()=>{
                    deleteCourse(course.id);
                }}
                >Delete</Button>
                {' '}
                <Button color="warning"
                onClick={()=>{
                    updateCourse(course.id);
                }}
                 >Update</Button>
            </Container>
        </CardBody>
    </Card>
);
}
export default Course;