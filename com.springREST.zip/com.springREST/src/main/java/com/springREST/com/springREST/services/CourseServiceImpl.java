package com.springREST.com.springREST.services;

//import java.util.ArrayList;
import java.util.List;
//import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springREST.com.springREST.dao.CourseDao;
import com.springREST.com.springREST.entities.Course;
@Service
public class CourseServiceImpl implements CourseService 
{
	//home
//	List<Course> list;
	@Autowired  
	private CourseDao courseDao;
	public CourseServiceImpl()
	{
//		list=new ArrayList<>();
//		list.add(new Course(135,"core java","its core java course"));
//		list.add(new Course(137,"python","its core python course"));
	}
	
	//get all course
	@Override
	public List<Course> getCourses()
	{
//		return list;
		
//		database configuration
		return courseDao.findAll();
	}
	
    //get course by course id
	@Override
	public Course getCourse(long courseId)
	{
//		Course c =null;
//		for(Course course:list)
//		{
//			if(course.getId()==courseId)
//			{
//				c=course;
//				break;
//			}
//		}
//		return c;
		//database implementation
		return courseDao.getOne(courseId);
	}
	
	//add course
	@Override
	public Course addCourse(Course course)
	{
//		list.add(course);
//		return course;
		
		//database configuration
		courseDao.save(course);
		return course;
	}
	
//update course by course id
	public Course updateCourse(Course course)
	{
//		list.forEach(e->{
//		if(e.getId()==course.getId())
//		{
//			e.setTitle(course.getTitle());
//			e.setDescription(course.getDescription());
//		}
//		});
//		return course;
		
		//database configuration
				courseDao.save(course);
				return course;
	}
    
//delete course by courseId
	@Override
	public void deleteCourse(long parseLong) {
//		list=list.stream().filter(e->e.getId()!=parseLong).collect(Collectors.toList());
//		database configuration
		
		Course Entity= courseDao.getOne(parseLong);
		courseDao.delete(Entity);
	}
}
